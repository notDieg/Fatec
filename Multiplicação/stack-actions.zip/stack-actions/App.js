import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [resultado, setResultado] = useState('');

  function multiplicar() {
    const resultado = parseFloat(num1) * parseFloat(num2);
    setResultado(resultado.toString());
  }

  return (
    <View style={styles.container}>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          onChangeText={text => setNum1(text)}
          value={num1}
          placeholder="Digite o primeiro número"
          keyboardType="numeric"
        />
        <TextInput
          style={styles.input}
          onChangeText={text => setNum2(text)}
          value={num2}
          placeholder="Digite o segundo número"
          keyboardType="numeric"
        />
      </View>
      <Button title="Multiplicar" onPress={multiplicar} />
      {resultado ? <Text style={styles.resultado}>O resultado da multiplicação é: {resultado}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  input: {
    height: 40,
    width: '40%',
    borderColor: 'gray',
    borderWidth: 1,
    marginRight: 10,
    paddingHorizontal: 10,
  },
  resultado: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
  },
});

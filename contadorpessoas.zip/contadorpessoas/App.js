import React, { Component } from 'react';
import { View, Text, Image, Button } from 'react-native';


class App extends Component{
  constructor(props){
    super(props);

    this.state = {
      valor: 0
      
    };


    this.soma = this.soma.bind(this);
    this.subtrai = this.subtrai.bind(this);
  }
  
  soma(){
    this.setState({
      valor:  this.state.valor + 1
    });
  }

  subtrai(){
    if(this.state.valor > 0){
        this.setState({
      
        valor:  this.state.valor - 1
    });
    }

  }


  render(){
    return(
      <View style={{ marginTop: 20 }}>

        <Text style={{fontSize: 30, textAlign: 'center'}}>Contador de Pessoas</Text>

        <br/><br/>

        <Text style={{fontSize: 72, color: 'green', textAlign: 'center'}}>
          {this.state.valor}
        </Text>
        <br/>
        <Button title="+" onPress={this.soma} />
        <br/>
        <Button title="-" onPress={this.subtrai} color= 'red' />

      </View>

    )
  }

}



export default App;
import React, { Component } from 'react';
import { View, StyleSheet, FlatList, Text } from 'react-native';

class App extends Component{


  constructor(props) {
    super(props);
    this.state = {
      feed:[
        {id: 1, cargo: 'Desenvolvedor BackEnd', salario: 'R$5.000,00',  desc: '----------------', cont: '(13) 9 1833 - 5571'},
        {id: 2, cargo: 'Engenheiro de Dados',   salario: 'R$8.000,00',  desc: '----------------', cont: '(13) 9 0912 - 8463'},
        {id: 3, cargo: 'Programador FullStack', salario: 'R$6.500,00',  desc: '----------------', cont: '(13) 9 2462 - 2455'},
        {id: 4, cargo: 'Scrum Master',          salario: 'R$15.000,00', desc: '----------------', cont: '(13) 9 6432 - 0185'},
        {id: 5, cargo: 'Analista de Dados',     salario: 'R$9.200,00',  desc: '----------------', cont: '(13) 9 5682 - 5683'},
      ]
    }
  }


  render(){
    return(
      
      <View style={styles.container}>
      <View style={styles.title}>
        <Text style={styles.title}>
            VAGAS
        </Text>
      </View>
        <FlatList 
        data={this.state.feed}
        keyExtractor={(item) => item.id}
        renderItem={ ({item}) => <Pessoa data={item}/>}
        />
      </View>
    )
  }
}


const styles = StyleSheet.create({
  container:{
    flex: 1,
    backgroundColor: 'gray',
  },
  pessoa:{
    height: 150,
    width: 300,
    padding: 40,
    borderRadius: 20,
    marginTop: 10,
    marginLeft: 10,
    backgroundColor: '#D3D3D3',
  },
  title:{
    textAlign: 'center',
    fontSize: 45,
    color: 'orange'
  },
  cargo:{
    color: 'green'
  }
})


export default App;


class Pessoa extends Component{
  render(){
    return(
      <View style={styles.pessoa}>
        <Text style={styles.cargo}> {this.props.data.cargo} </Text>
        <Text> Salário: {this.props.data.salario} </Text>
        <Text> Descrição: {this.props.data.desc} </Text>
        <Text> Contato: {this.props.data.cont} </Text>
      </View>
    );
  }
}
